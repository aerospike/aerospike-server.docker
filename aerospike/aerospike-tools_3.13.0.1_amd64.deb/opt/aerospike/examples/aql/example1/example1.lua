function foo()
   return 5
end
